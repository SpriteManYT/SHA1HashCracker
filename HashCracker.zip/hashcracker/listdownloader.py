import hashlib
import os
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
RESET = "\033[0m"
def clear_screen():
    if platform.system() == 'Windows':
        os.system('cls')
    else:
        os.system('clear')
while True:
    try:
        import requests
        break
    except ImportError:
        os.system("pip3 install requests")
        clear_screen

url = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/xato-net-10-million-passwords.txt"
print(f"{GREEN}[+] loading...")
r = requests.get(url)
clear_screen
print(f"{GREEN}[+] loaded passwords...")

if r.status_code == 200:
    current_directory = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_directory, "hashlist.txt")
    with open(file_path, "w") as file:
        for line in r.iter_lines():
            if line.strip():  # Check if line is not empty
                hashed = hashlib.sha1(line).hexdigest()
                file.write(f"{hashed}:{line.decode()}\n")
        print(f"{YELLOW}[!] List successfully downloaded!{RESET}")
        input("")
else:
    print(f"{RED}[-] Failed to fetch data from the URL.")