import os
import platform
import time

# ANSI escape codes for colors
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
PURPLE = "\033[35m"
RESET = "\033[0m"  # Reset to default color
def clear_screen():
    if platform.system() == 'Windows':
        os.system('cls')
    else:
        os.system('clear')

def main():
    clear_screen()
    hash_input = input(f"{GREEN}[+]{RESET} {YELLOW}Enter hash:{RESET} ").strip().lower()
    clear_screen()
    current_directory = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_directory, "hashlist.txt")
    with open(file_path, 'r') as file:
        hashlist = file.readlines()
    
    found = False
    for line in hashlist:
        if hash_input in line.lower():
            print(f"{GREEN}[+]{RESET} {YELLOW}{line.strip()}{RESET}")
            input("")
            found = True
            break
    
    if not found:
        print(f"{RED}[-] Password not found{RESET}")
        input("")

if __name__ == "__main__":
    main()
