clear
echo "enter hash:"
read hash
clear
result=$(grep -i $hash hashlist.txt)
if [ -z "$result" ]; then
	echo "password not found"
else
	echo "$result"
fi

